# EnKF debugging — summary of findings and changes

This is a handoff of work on `run_floc_model_enkf1.jl`, which wasn't converging.
`FINDINGS.md` has the detailed evidence; this file is the overview.

**Original files are untouched.** `run_floc_model_enkf1.jl` is unchanged and not
included here. The only file modified in place is `floc_mod_enkf.jl`; the new driver
is a separate file.

---

## The short version

There were ten separate problems. The filter was the *least* of them — the forward
model was the dominant cause, observation weighting second, filter formulation third.

Three findings account for most of the failure:

**1. The flocculation model was switched off.** `alpha0 = 0.0` and `beta0 = 0.0` on
lines 72–73 of `enkf1` (the working values are commented out on the same lines). With
both zero, the aggregation and break-up kernels vanish identically and `run_floc_mod`
returns its input unchanged — verified, `max|n − n₀|` is exactly 0.0 after 200 steps.
The forward model was the identity map, so nothing connected the parameters to the
observations and every parameter update was sampling noise.

**2. Aggregates were being placed in the wrong size class.** The kernel put the
product of classes *j* and *m* into class *j+m*. That's only valid on a grid linear in
particle mass; this grid is geometric in diameter, so it overshoots badly — two 32 µm
flocs produced a 1038 µm floc instead of 44 µm. Aggregation was teleporting mass above
the LISST range (459 µm) where it can't be seen, so **no parameter choice could have
made the model match the data.**

**3. Three LISST rings were dominating the whole analysis.** Rings 1–3 (1.21 / 1.60 /
1.89 µm) carry a constant placeholder variance of 8.3×10⁻⁹ µL/L² in every record,
against a model value of ~0.25 µL/L there. That's a −2818σ innovation. Satisfying it
means deleting ~5×10¹¹ particles/m³ from the finest class — which is exactly where the
"particle counts get extremely high" symptom came from.

The rest: the initial condition was 10⁴× too small in volume (so all the sediment in
the run was manufactured by the noise term); 22% of the observation rows are dead
zeros and were being assimilated as certain; there were no perturbed observations, so
the ensemble collapsed 0.33× per analysis; `nf = nf0·sin(Nfs)²` is many-to-one and so
structurally unidentifiable; the aggregation loss term was under-counted by 4×10⁵;
`dt = 1 s` is unstable by three orders of magnitude once the initial condition is
correct; and there was a `@threads` race that silently corrupted ensemble members.

---

## On the three hypotheses in the original question

- **Noise in the ensemble** — yes. `abs.(randn())` is a biased positive source, not
  noise, and it was doing all the work of putting sediment in the water.
- **Observation operator** — yes. Bin centres instead of edges, and all seven
  out-of-range classes aliased into the last ring, making that row 50× larger than any
  other.
- **Ill-posedness from huge particle counts** — yes, and this was the right instinct.
  The state spans ~12 orders of magnitude and H entries scale as D³ over a 1.7×10⁹
  range; a Gaussian update in that space drove 20% of the state negative at every
  analysis. Assimilating **log-volume** instead is the fix. But it wouldn't have been
  enough on its own — the model had to be corrected first.

---

## What changed

### `floc_mod_enkf.jl` (modified in place)

- **`l1`** — removed a spurious `1/particle_density[k]` that under-counted the
  aggregation sink by 4.1×10⁵. This was the `# need to fix mass balance` TODO.
- **`run_floc_mod`** — `n_new[1] -= mass_change` had the wrong sign; that quantity is
  the deficit, so the patch doubled the error instead of cancelling it.
- **`calculate_closest_half_mass`** — built a `Vector{Float64}` and relied on the
  constructor to convert to the declared `Vector{Int}`, which throws `InexactError`
  once `particle_density` goes non-finite.
- **`calculate_mass`** — corrected the fractal scaling (cosmetic; only `mass[1]` was
  ever used, and that value was already right).
- **`init_params`** — now accepts a precomputed collision matrix. It only depends on
  D, and recomputing it per member per step was most of the runtime.
- **New `run_floc_mod_semi`** — fixed-pivot aggregation with implicit, flux-limited
  sinks. Unconditionally positive, no sub-cycling, mass conserves to 1e-16. Validated
  against a heavily sub-cycled explicit reference.

### `run_floc_model_enkf2.jl` (new)

A parallel driver. Every change is tagged `[F1]`…`[F13]` inline, next to the
measurement that motivated it. Main points: initial condition inverted from the first
valid LISST spectrum; monotone bounded parameter transforms; observation operator
built from log-midpoint bin edges with out-of-range classes left unobserved; ring and
dead-record QC plus a variance floor on R; perturbed observations; log-volume state
with log-space observations; two-block Gaspari-Cohn localization; RTPP inflation; and
a seeded RNG.

---

## Regularization that mattered, ranked

1. **Log-volume state** rather than particle counts — negatives went 20% → 0%.
2. **Two-block covariance localization** in log-diameter. Taper *both* `Cxy` and
   `Cyy`; tapering only `Cxy` diverges hard. Largest filter-side win: misfit reduction
   per analysis −18% → −42%.
3. **Log-space observations** with delta-method R. Reported LISST std/obs runs
   0.5–2.2, so the error is multiplicative, not additive.
4. **Variance floor on R** — literally Tikhonov regularization of the inverse in
   `S = HPHᵀ + R`.
5. **RTPP rather than RTPS** — the state is a log, so RTPS's unbounded factor gets
   exponentiated on the back-transform.

---

## Result

Three independent seeds, 4-hour windows, 47 analyses each:

| | seed 11 | seed 22 | seed 33 |
|---|---|---|---|
| chi²/p (typical) | 0.6–1.0 | 0.6–1.0 | 0.6–1.0 |
| misfit at t=1.75 h | 9.00 → 4.97 | 8.48 → 5.17 | 8.74 → 5.17 |
| model/observed volume | 0.67–1.04 | 0.64–1.27 | 0.63–1.27 |
| α | 1e-3 | 1e-3 | 1e-3 |
| nf | 2.74 | 2.76 | 2.78 |

chi²/p ≈ 1 means the ensemble spread is statistically consistent with the actual
misfit. It was 18–237 before. Independent seeds converging on the same parameters is
the real evidence it's working.

---

## Caveats — please read before using any of this

- **The parameter values are not comparable to earlier runs.** The fixed-pivot rewrite
  changes flocculation behaviour substantially. It also implies `alpha0 = 0.35` is
  ~100× too large for this collision kernel: it drives d50 to ~1050 µm in five
  minutes, against an observed median d50 of 78 µm. The filter settles at α ≈ 10⁻³.
- **Validated on 4-hour windows only**, not the full 14-day record.
- **The 0-D box cannot create sediment.** There's no erosion, deposition or advection,
  so total suspended mass is fixed by the initial condition — but the observed LISST
  load swings from 25 to 5850 µL/L. Asking α/β/nf to explain that is genuinely
  ill-posed. This shows up as model/observed volume drifting to ~0.63 when the load
  rises. A mass-source term (what the commented-out `Flux` term was reaching for) is
  implemented but **off by default** — as a free random walk the filter runs it away,
  so it now has a mean-reverting prior. Turn it on once you're happy with the rest and
  watch the `msrc` output.
- Two of the biggest findings look like debugging state that didn't get reverted
  (`alpha0 = 0.0` with the real value commented on the same line; the `ic` array
  divided by 100 and disabled), so they may be less surprising to you than they were
  to me.

---

## Files here

| file | what it is |
|---|---|
| `README.md` | this file |
| `FINDINGS.md` | detailed writeup, every claim with its measurement |
| `floc_mod_enkf.jl` | modified — drop in to replace the existing one |
| `run_floc_model_enkf2.jl` | new driver, add alongside `enkf1` |
| `changes.patch` | `git diff` of the above, if you'd rather apply it than copy files |

The data files aren't included — they're unchanged and you already have them.

## Running it

```bash
ENKF_DATA_DIR=$PWD julia -t 4 run_floc_model_enkf2.jl
```

`ENKF_M` sets the step count, `ENKF_SEED` the RNG seed. The RNG is now seeded by
default — `enkf1` left it unseeded, so no two runs were comparable, which matters when
the filter is only marginally stable. Fix it while tuning, sweep it when validating.

Data paths now come from `ENKF_DATA_DIR` (defaulting to the script's own directory)
rather than being hardcoded to `/global/homes/s/siennaw/...`, so it runs locally as
well as on Perlmutter.
