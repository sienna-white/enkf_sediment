# Why the EnKF in `run_floc_model_enkf1.jl` wasn't converging

Ten separate issues, spanning the forward model, the observation handling, and the
filter itself. Every claim below is a measured number, not a guess. The fixes live in
`run_floc_model_enkf2.jl` (new; `enkf1` is untouched) and in `floc_mod_enkf.jl`
(modified in place), tagged `[F1]`…`[F13]`.

Short version of the ranking: **the forward model was the dominant problem**, the
observation weighting second, and the filter formulation third. The ill-posedness was
real, but fixing it alone would not have been enough.

---

## Forward model

### 1. The model was switched off
`alpha0 = 0.0` and `beta0 = 0.0` (enkf1 lines 72–73; the working values sit commented
out on the same lines). With α = β = 0 both kernels vanish and `run_floc_mod` returns
its input unchanged — verified, `max|n − n₀|` is **exactly 0.0** after 200 steps.

The forward model was the identity map. Nothing linked the parameters to the
observations, so every parameter "update" was sampling noise. Measured spurious
|correlation| between parameters and observations reached **0.28** (the noise floor
for N=65 is ~0.12).

### 2. Aggregates were placed in the wrong size class
The kernel put the product of classes *j* and *m* into class *j+m*. Index addition is
only valid on a grid linear in particle **mass**; this grid is geometric in diameter.

| collision | code gave | correct | error |
|---|---|---|---|
| 15.6 + 15.6 µm | 244 µm | 21.4 µm | 11× |
| 32.2 + 32.2 µm | 1038 µm | 44.2 µm | 23× |
| 15.6 + 66.4 µm | 1038 µm | 67.7 µm | 15× |

Aggregation teleported mass above the LISST range (459 µm), where it is unobservable.
**No parameter choice could have made the modelled spectrum match the data.** This is
the deepest single reason the filter could not converge.

Fixed with a Kumar–Ramkrishna fixed-pivot scheme: a collision of classes *i* and *j*
yields `pd_i + pd_j` primary particles, split between the two bracketing classes so
mass conserves exactly.

### 3. `alpha0 = 0.35` is ~100× too large
With the sizing fixed, α = 0.35 drives d50 to ~1050 µm within five minutes. The LISST
record has median d50 = **78 µm** (range 34–393). A direct sweep puts the working
value at α ≈ 3.5e-3 (d50 82–139 µm). The filter independently settles at 1–3e-3 from
three different seeds.

### 4. `dt = 1 s` is unstable by three orders of magnitude
`run_floc_mod` is explicit Euler, stable only while `dt · max_loss_rate < 1`. At
physically-sized concentrations that limit is **7×10⁻⁴ s** at G=175, not 1 s.

This never surfaced because the initial condition was 10⁴× too small (see §6), which
kept the rates artificially tiny. Fixing the IC alone makes the explicit scheme blow
up to n ~ 10²⁶. Replaced with an implicit, flux-limited step (`run_floc_mod_semi`) —
unconditionally positive, no sub-cycling, validated against a heavily sub-cycled
explicit reference.

### 5. Mass-balance bugs in `floc_mod_enkf.jl`
- `l1` carried a spurious `1/particle_density[k]`, under-counting the aggregation sink
  by **4.1×10⁵**. (The `# need to fix mass balance` comment was on exactly this line.)
- `n_new[1] -= mass_change` has the wrong sign — that quantity is the *deficit*, so
  the patch doubled the error instead of cancelling it.
- Mass aggregating past the top class was deleted: **47% of total mass in 5 minutes**,
  at a per-member rate depending on α and nf, so ensemble total mass fanned out 3.6×
  between analyses. The top class is now absorbing; mass conserves to 1e-16.
- `calculate_closest_half_mass` built a `Vector{Float64}` and relied on the
  constructor to convert to the declared `Vector{Int}` — throws `InexactError` as soon
  as nf runs away, surfacing as an opaque `TaskFailedException` inside `@threads`.

---

## Observations

### 6. The initial condition was ~10⁴× too small
The IC is 2.6×10⁻³ µL/L; the first LISST record is 25.3 µL/L. The commented-out
`ic = [...]` vector on enkf1 line 64 was the right magnitude (29.3 µL/L) — it had been
divided by 100 and disabled.

Consequence: **all** sediment in the old runs was manufactured by the
`randn .* (1e-8./Volumes')` noise term. That is a random walk, so total load grew like
√t, anchored to nothing physical. Now the IC is inverted from the first valid LISST
spectrum.

### 7. Three LISST rings were dominating the entire analysis
Rings 1–3 (1.21 / 1.60 / 1.89 µm) carry a **constant placeholder variance** of
8.3×10⁻⁹ µL/L² (std 9×10⁻⁵) in *every single record*, while the model sits at ~0.25
µL/L there. That is a **−2818σ innovation**.

Removing 0.25 µL/L from a bin whose particles have V = 5.2×10⁻¹⁹ m³ requires deleting
~5×10¹¹ particles/m³ — and the measured increment for class 1 was −3.2×10¹¹. **This is
the origin of the "particle counts get extremely high" symptom.** Those rings are also
the least trustworthy on a LISST. Now dropped.

### 8. 22% of observation rows are dead
883 of 3976 rows in `lisst_data.csv` are identically zero across all 36 rings. They
were being assimilated as "the water is perfectly clear, and I am certain." Now
rejected.

### 9. The observation operator aliased the out-of-range classes
`H` was built by walking LISST bin *centres* and assigning each model class to the
first centre ≥ D, with an `if i == N_lisst` fallback. That swept all 7 model classes
above 459 µm into ring 36. Because H entries scale as D³, that row ended up **50×
larger** than any other (row sum 2.5e-3 vs 4.6e-5) and dominated the analysis. Now
uses proper log-midpoint edges, and out-of-range classes are simply unobserved.

---

## Filter

### 10. No perturbed observations
Every member received the same innovation (`observations .- H * x_e`) — the classic
stochastic-EnKF bug. Without perturbing the observations the analysis covariance is
systematically too small. Measured spread collapse: **0.33× at every analysis**,
masked only by the biased `abs.(randn())` noise re-inflating it between steps.

### 11. `nf = nf0 * sin(Nfs)^2` is structurally unidentifiable
Periodic and many-to-one (`Nfs` and `−Nfs` give the same nf), and it sweeps through
nf = 0 (a fractal dimension of zero is unphysical; it should live in ~[1.4, 3]). An
EnKF moves a parameter only through its linear correlation with the observations, and
a symmetric many-to-one map drives that correlation to zero. All four parameters now
use monotone, bounded transforms.

### 12. Biased "noise"
`ssc += abs.(randn(N, Ns))` — `abs()` of a normal has mean 0.798, so this is a
deterministic positive source of ~0.8 particles/class/step, not noise. Combined with
`clamp!(ssc, 0, Inf)` applied *after* the perturbation (which biases the mean upward
again), the ensemble mean was being driven by its own noise term. Replaced with
zero-mean multiplicative (lognormal) model error.

### 13. A threading race in the driver
Worth flagging for the other scripts too. Variables assigned inside a `@threads` body
can be boxed by Julia's closure conversion and shared across tasks. It ran without
error but produced prior volume of **1.7×10⁵ µL/L against observations of 25**;
`julia -t 1` gave the correct 23.8. That discrepancy between thread counts is the
tell. Fixed by moving per-member work into a top-level `advance_member!` — now
bit-identical at `-t 1` and `-t 4`.

---

## Regularization, ranked by payoff

The state is a particle-number spectrum spanning ~12 orders of magnitude, and H
entries scale as D³ over a 1.7×10⁹ range. A Gaussian update in that space is badly
ill-posed — measured on the shipped configuration it drove **20% of the state
negative** at every analysis, with increments the size of the entire state.

1. **Assimilate log-volume, not particle counts.** Makes the operator a 0/1 binning
   matrix, compresses dynamic range from 10¹² to ~30, and enforces positivity
   structurally. Negatives went 20% → 0%.
2. **Two-block covariance localization.** Gaspari-Cohn in log-diameter — but taper
   **both** `Cxy` and `Cyy`. Tapering only `Cxy` leaves the gain inconsistent with the
   innovation covariance it is inverted against, and the filter diverges hard (volume
   blew up 17 orders of magnitude). Done correctly it was the largest filter-side win:
   misfit reduction per analysis −18% → **−42%**.
3. **Log-space observations** with delta-method R (`var(log y) ≈ var(y)/y²`). Reported
   LISST std/obs runs 0.5–2.2, i.e. the error is multiplicative, not additive.
   Comparing a log state against linear observations overshoots badly (measured misfit
   21 → 839 µL/L in a single analysis).
4. **Tikhonov floor on R** (10% relative + 0.02 µL/L absolute). This is exactly
   Tikhonov regularization of the inverse in `S = HPHᵀ + R` — it bounds the gain
   instead of letting near-zero reported variances drive it to infinity.
5. **RTPP, not RTPS.** The state is a log, so RTPS's unbounded inflation factor gets
   exponentiated on the back-transform (log-spread went 0.15 → 62 in three hours).
   RTPP is a convex blend and cannot exceed the prior spread.
6. **Spread cap.** The back-transform bias on ensemble-mean volume is `exp(σ²/2)` — at
   σ = 3 that is a factor of 90. Capped at σ = 1.
7. **Tighter parameter prior.** `randn(N)` (sd 1) spans essentially the whole
   admissible range of every parameter, so members diverge over the 300 s between
   analyses and log-spread reaches 2.3 (a 14× high bias on mean volume). sd 0.35 keeps
   observation-space spread at 0.66 and the bias at 1.25×.

---

## Result

Three independent seeds, 4-hour windows, 47 analyses each:

| | seed 11 | seed 22 | seed 33 |
|---|---|---|---|
| chi²/p (typical) | 0.6–1.0 | 0.6–1.0 | 0.6–1.0 |
| misfit at t=1.75 h | 9.00 → 4.97 | 8.48 → 5.17 | 8.74 → 5.17 |
| model/observed volume | 0.67–1.04 | 0.64–1.27 | 0.63–1.27 |
| log-volume spread | 0.28–0.37 | 0.28–0.39 | 0.27–0.38 |
| α | 1e-3 | 1e-3 | 1e-3 |
| β | 0.045 | 0.032 | 0.031 |
| nf | 2.74 | 2.76 | 2.78 |

chi²/p ≈ 1 means the ensemble spread is statistically consistent with the actual
misfit — that is the target, and it was 18–237 before. Independent seeds converging on
the same parameters is the real evidence the filter is working.

## Known limitations

- **Model/observed volume drifts to ~0.63 late in the window** as the observed load
  rises, and chi²/p rises to 6–9 at the same times. Same cause: this is a 0-D box with
  no erosion, deposition, or advection, so total suspended mass is fixed by the initial
  condition — but the observed LISST load swings from 25 to 5850 µL/L over the record.
  Asking α/β/nf to explain that is genuinely ill-posed; no combination of them can
  create sediment.
- A mass-source term (`[F13]`, what the commented-out `Flux` term was reaching for) is
  implemented but **off by default**. It is an integrating control, and as a free
  random walk the filter runs it away (model/observed volume reached 1.5×10⁹). It now
  has an Ornstein-Uhlenbeck prior; turn it on once you're happy with the rest and watch
  the `msrc` output variable.
- Validated on 4-hour windows only, not the full 14-day record.
- The fixed-pivot rewrite changes flocculation behaviour substantially. The parameter
  values it converges to (α ~ 1e-3) are not comparable to anything from before.

## Running it

```bash
ENKF_DATA_DIR=$PWD julia -t 4 run_floc_model_enkf2.jl
```

`ENKF_M` sets the step count, `ENKF_SEED` the RNG seed. The RNG is now seeded by
default — enkf1 left it unseeded, so no two runs were comparable, which matters a lot
when the filter is only marginally stable. Fix it while tuning; sweep it when
validating.
